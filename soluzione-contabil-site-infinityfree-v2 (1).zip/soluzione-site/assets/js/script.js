const header=document.querySelector('.nav'),menu=document.querySelector('.menu');
menu?.addEventListener('click',()=>{const open=header.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
document.querySelectorAll('#navlinks a').forEach(a=>a.addEventListener('click',()=>header.classList.remove('open')));
document.getElementById('year').textContent=new Date().getFullYear();
const form=document.getElementById('contactForm'),status=document.getElementById('formStatus');
form?.addEventListener('submit',e=>{e.preventDefault();status.textContent='Mensagem preparada. No InfinityFree, conecte este formulário a um endpoint de e-mail ou formulário externo antes de publicar.';form.reset();});
const observer=new IntersectionObserver(entries=>entries.forEach(x=>{if(x.isIntersecting)x.target.classList.add('visible')}),{threshold:.08});
document.querySelectorAll('.cards article,.steps div,.testimonial-grid blockquote,.facts div').forEach(x=>{x.style.opacity='0';x.style.transform='translateY(14px)';x.style.transition='opacity .6s ease,transform .6s ease';observer.observe(x)});
document.addEventListener('scroll',()=>document.querySelectorAll('.visible').forEach(x=>{x.style.opacity='1';x.style.transform='translateY(0)'}),{passive:true});
