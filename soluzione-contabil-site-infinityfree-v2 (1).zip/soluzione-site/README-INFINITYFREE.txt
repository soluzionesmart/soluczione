SOLUZIONE CONTÁBIL — SITE ESTÁTICO
1. Envie todo o conteúdo desta pasta para public_html no InfinityFree.
2. Substitua SEU-DOMINIO.infinityfreeapp.com em index.html pelo domínio real.
3. O site não depende de PHP, banco de dados ou bibliotecas externas.
4. O formulário é demonstrativo: antes de receber mensagens reais, conecte-o a um serviço/endereço de processamento de formulários.
5. Para Google Ads, não existe garantia de aprovação. Revise também a conta, anúncios, destino, oferta, consentimento/cookies e políticas do Google antes de anunciar.
6. Não publique telefone/e-mail mascarados se eles forem necessários para contato; substitua pelos dados reais da empresa.
